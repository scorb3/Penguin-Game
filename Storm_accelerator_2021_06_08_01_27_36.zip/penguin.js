class Penguin {
  constructor(){
    this.r = 120;
    this.x = 30;
    this.y = height - this.r;
    this.vy = 0;
    this.gravity = 2;
  }
  
  jump(){
    if (this.y == height - this.r) {
      this.vy = -30;
    }
  }
  
  hits(ice){
    return collideRectRect(this.x, this.y, this.r, this.r, ice.x, ice.y, ice.r, ice.r);
  }
  
  move(){
    this.y += this.vy;
    this.vy += this.gravity;
    this.y = constrain(this.y, 0, height - this.r);
  }
  
  
  
  show() {
    image(pImg,this.x, this.y, this.r, this.r);
  }
  
}