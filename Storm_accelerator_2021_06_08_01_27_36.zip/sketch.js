let penguin;
let pImg;
let iImg;
let bImg;
let fImg;
let ice = [];

function preload() {
  pImg = loadImage("betterp.jpg");
  iImg = loadImage("please2.jpg");
  bImg = loadImage("background.jpg");
  fImg = loadImage("frontpage.jpg");
}

function setup() {
  createCanvas(750, 450);
  penguin = new Penguin();
}

function keyPressed() {
  if (key == " ") {
    penguin.jump();
  }
}

function draw() {
  if (random(1) < 0.011) {
    ice.push(new Ice());
  }

  background(bImg);

  for (let i of ice) {
    i.move();
    i.show();
    if (penguin.hits(i)) {
      console.log("game over");
      noLoop();
    }
  }

  penguin.show();
  penguin.move();
}
